# Erzeugt alle Fluxwerk-Texturen (16x16, teils animiert) per Code. Eigene Gestaltung.
from PIL import Image
import math, os, json
R = os.path.join(os.path.dirname(__file__), "..", "src/main/resources/assets/fluxwerk")
TB = os.path.join(R, "textures/block"); TI = os.path.join(R, "textures/item")
os.makedirs(TB, exist_ok=True); os.makedirs(TI, exist_ok=True)

STEEL=(58,70,86); STEEL_D=(30,38,50); STEEL_L=(92,108,130); STEEL_H=(132,150,172)
TEAL=(46,230,200); TEAL_D=(18,128,118); AMBER=(255,176,46)
COPPER=(184,108,52); COPPER_D=(112,60,28); COPPER_L=(238,166,96)
WATER=(63,118,228); LAVA=(255,122,24); MILK=(242,242,234)
DARK=(16,20,28)

def hsh(x,y,s=0):
    n=(x*374761393+y*668265263+s*2147483647)&0xFFFFFFFF
    n=((n^(n>>13))*1274126177)&0xFFFFFFFF
    return ((n^(n>>16))&255)/255.0
def cl(v): return max(0,min(255,int(v)))
def mix(a,b,t): return tuple(cl(a[i]*(1-t)+b[i]*t) for i in range(3))
def sh(c,f): return tuple(cl(v*f) for v in c)
def new(): return Image.new("RGBA",(16,16),(0,0,0,0))

def save(im,name,d=TB): im.save(os.path.join(d,name+".png"))
def save_anim(frames,name,ft=2,d=TB,interp=True):
    n=len(frames); s=Image.new("RGBA",(16,16*n))
    for i,f in enumerate(frames): s.paste(f,(0,16*i))
    s.save(os.path.join(d,name+".png"))
    meta={"animation":{"frametime":ft}}
    if interp: meta["animation"]["interpolate"]=True
    json.dump(meta,open(os.path.join(d,name+".png.mcmeta"),"w"))

def plate(base=STEEL,seed=0,rivets=True):
    im=new(); p=im.load()
    for y in range(16):
        for x in range(16):
            c=tuple(cl(base[i]+(hsh(x,y,seed)-0.5)*10) for i in range(3))
            if x==0 or y==0: c=mix(c,STEEL_H,0.35)
            if x==15 or y==15: c=mix(c,STEEL_D,0.6)
            p[x,y]=c+(255,)
    if rivets:
        for rx,ry in ((2,2),(13,2),(2,13),(13,13)):
            p[rx,ry]=STEEL_H+(255,); p[rx,ry+1]=STEEL_D+(255,)
    return im

def disc(im,cx,cy,r,col,r0=0):
    p=im.load()
    for y in range(16):
        for x in range(16):
            d=math.hypot(x+0.5-cx,y+0.5-cy)
            if r0<=d<=r: p[x,y]=col+(255,)

# ---------------------------------------------------------------- Rohre & Kabel
def conduit(lo,hi,main,ring,flow=None,frame=0,n=8,flowcol2=None):
    im=new(); p=im.load()
    for y in range(16):
        for x in range(16):
            inH=lo<=y<hi; inV=lo<=x<hi
            c=sh(main,0.55)
            def band(t):
                e=abs(t*2-1)
                return 1.18-0.55*e
            if inH:
                t=(y-lo)/(hi-lo-1); c=sh(main,band(t))
                if flow is not None and 0.2<t<0.8:
                    w=0.5+0.5*math.sin(2*math.pi*(x/8.0-frame/n))
                    c=mix(flow,flowcol2 or (255,255,255),w*0.35)
                if x in (2,13) or (x in (3,12) and False): c=ring
            if inV:
                t=(x-lo)/(hi-lo-1); c2=sh(main,band(t))
                if flow is not None and 0.2<t<0.8:
                    w=0.5+0.5*math.sin(2*math.pi*(y/8.0-frame/n))
                    c2=mix(flow,flowcol2 or (255,255,255),w*0.35)
                if y in (2,13): c2=ring
                c = c2 if not inH else mix(sh(main,1.05),STEEL_H,0.2)
            if inH and inV:
                edge = x in (lo,hi-1) or y in (lo,hi-1)
                c = sh(ring,0.7) if edge else mix(sh(main,1.1),STEEL_H,0.25)
            p[x,y]=c+(255,)
    return im

save(conduit(5,11,STEEL_L,TEAL_D),"pipe")
for nm,col,c2 in (("water",WATER,(190,225,255)),("lava",LAVA,(255,235,120)),("milk",MILK,(255,255,255))):
    save_anim([conduit(5,11,STEEL_L,TEAL_D,flow=col,frame=f,flowcol2=c2) for f in range(8)],"pipe_"+nm,2)
save(conduit(6,10,COPPER,STEEL_D),"cable")
save_anim([conduit(6,10,COPPER,STEEL_D,flow=(255,196,70),frame=f,flowcol2=(255,250,200)) for f in range(8)],"cable_lit",2)

# ---------------------------------------------------------------- Tank
def tank_frame():
    im=new(); p=im.load()
    for y in range(16):
        for x in range(16):
            border = x<2 or x>13 or y<2 or y>13
            if border:
                c=tuple(cl(STEEL[i]+(hsh(x,y,3)-0.5)*10) for i in range(3))
                if x in (0,15) or y in (0,15): c=sh(STEEL_D,1.0)
                elif x in (1,14) or y in (1,14): c=STEEL_L
                p[x,y]=c+(255,)
    for rx,ry in ((0,0),(15,0),(0,15),(15,15),(1,1),(14,1),(1,14),(14,14)): p[rx,ry]=TEAL_D+(255,)
    return im
save(tank_frame(),"tank")

def fluid_frame(kind,f,n=16):
    im=Image.new("RGBA",(16,16)); p=im.load(); a=2*math.pi*f/n
    for y in range(16):
        for x in range(16):
            if kind=="water":
                v=math.sin(x*0.7+a)+math.sin(y*0.9-a)+math.sin((x+y)*0.5+2*a)
                t=(v+3)/6; c=mix((38,86,205),(130,185,255),t**1.6)
            elif kind=="lava":
                v=math.sin(x*0.8+a)+math.sin(y*0.6-a)+math.sin((x*y)*0.07+a)+ (hsh(x,y,5)-0.5)*0.8
                t=(v+3)/6; c=mix((170,40,5),(255,205,60),max(0,min(1,t))**1.3)
            else:
                v=math.sin(x*0.5+a)+math.sin(y*0.5-a)
                t=(v+2)/4; c=mix((230,230,222),(255,255,250),t)
            p[x,y]=c+(255,)
    return im
save_anim([fluid_frame("water",f) for f in range(16)],"fluid_water",3)
save_anim([fluid_frame("lava",f) for f in range(16)],"fluid_lava",4)
save_anim([fluid_frame("milk",f,8) for f in range(8)],"fluid_milk",4)

# ---------------------------------------------------------------- Zahnrad / Wirbel
def gear(angle,col=COPPER_L,body=COPPER_D):
    im=plate(STEEL,seed=7,rivets=False); p=im.load()
    for y in range(16):
        for x in range(16):
            dx,dy=x+0.5-8,y+0.5-8; r=math.hypot(dx,dy); th=math.atan2(dy,dx)
            tooth=1.0 if math.cos(6*(th-angle))>0.2 else 0.0
            ro=5.0+1.6*tooth
            if 2.0<=r<=ro:
                spoke=abs(math.cos(3*(th-angle)))>0.8 or r>4.2
                p[x,y]=(col if spoke else body)+(255,)
            elif r<2.0: p[x,y]=DARK+(255,)
    return im
def swirl(f,n=8,c1=TEAL,c2=(10,40,50),size=6.2,hole=True,base=None):
    im=base.copy() if base else plate(STEEL,seed=9,rivets=False); p=im.load()
    for y in range(16):
        for x in range(16):
            dx,dy=x+0.5-8,y+0.5-8; r=math.hypot(dx,dy); th=math.atan2(dy,dx)
            if r<=size:
                v=0.5+0.5*math.sin(3*th+0.9*r-2*math.pi*f/n)
                c=mix(c2,c1,v); 
                if r>size-1: c=sh(c,0.6)
                p[x,y]=c+(255,)
    return im

# Pumpe
def port(ring):
    im=plate(STEEL,seed=2); disc(im,8,8,6,ring,0); disc(im,8,8,4.5,DARK); 
    p=im.load()
    for i in range(4,12): p[i,8]=STEEL_D+(255,); p[8,i]=STEEL_D+(255,)
    return im
save(port(TEAL),"pump_front"); save(port((70,130,230)),"pump_back")
save(gear(0.0,STEEL_L,STEEL_D),"pump_side")
save_anim([gear(math.radians(60.0*f/8)) for f in range(8)],"pump_side_on",2)
# Saugeinheit
def mouth(f=None):
    im=plate(STEEL,seed=4); disc(im,8,8,6.5,TEAL_D); 
    if f is None:
        disc(im,8,8,5.5,DARK); p=im.load()
        for i in range(3,13):
            p[i,6]=STEEL_D+(255,); p[i,10]=STEEL_D+(255,); p[6,i]=STEEL_D+(255,); p[10,i]=STEEL_D+(255,)
    else:
        im=swirl(f,8,TEAL,(6,36,44),5.6,base=im)
    return im
save(mouth(),"suction_front"); save_anim([mouth(f) for f in range(8)],"suction_front_on",2)
def suction_side():
    im=plate(STEEL,seed=5); p=im.load()
    for y in range(3,13):
        p[3,y]=TEAL_D+(255,); p[4,y]=TEAL+(255,)
    for x in range(6,13):
        for y in (4,7,10): p[x,y]=STEEL_D+(255,)
    return im
save(suction_side(),"suction_side")
im=plate(STEEL,seed=6); disc(im,8,8,3.5,STEEL_D); disc(im,8,8,2,TEAL_D); save(im,"suction_back")

# Ventil
def valve_top(on):
    im=plate(STEEL,seed=11); col=(70,210,110) if on else (225,70,60)
    disc(im,8,8,6,col,4.8); p=im.load()
    for i in range(3,13): p[i,8]=sh(col,0.8)+(255,); p[8,i]=sh(col,0.8)+(255,)
    disc(im,8,8,1.6,STEEL_H); return im
save(valve_top(True),"valve_top_open"); save(valve_top(False),"valve_top_closed")
im=plate(STEEL,seed=12); p=im.load()
for x in range(16):
    for y in (1,2,13,14): p[x,y]=sh(STEEL_L,1.1 if y<8 else 0.8)+(255,)
for y in range(4,12): p[7,y]=TEAL_D+(255,); p[8,y]=TEAL+(255,)
save(im,"valve_side")
im=plate(STEEL,seed=13); disc(im,8,8,6,STEEL_L); disc(im,8,8,4.5,DARK); disc(im,8,8,6,TEAL_D,5.2); save(im,"valve_port")

# Filter
for k,col in (("none",(70,76,86)),("water",WATER),("lava",LAVA),("milk",MILK)):
    im=plate(STEEL,seed=14); p=im.load()
    for y in range(4,12):
        for x in range(4,12):
            edge = x in (4,11) or y in (4,11)
            p[x,y]=(TEAL if edge else mix(col,(255,255,255),0.18 if (x+y)%5==0 else 0))+(255,)
    if k=="none":
        for i in range(5,11): p[i,i]=STEEL_H+(255,); p[i,15-i]=STEEL_H+(255,)
    save(im,"filter_"+k)

# Messgeraet
def gauge(level):
    im=plate(STEEL,seed=15); disc(im,8,8,6.5,STEEL_D); disc(im,8,8,5.5,(214,224,234)); p=im.load()
    for i in range(5):
        a=math.radians(-225+i*(270/4)); 
        x=int(8+4.6*math.cos(a)); y=int(8-4.6*math.sin(a)) if False else int(8+4.6*math.sin(a))
    ang=math.radians(135+level*(270/4))   # 0 -> links unten, 4 -> rechts unten
    for t in range(0,11):
        r=t*0.4; x=int(8+r*math.cos(ang)); y=int(8+r*math.sin(ang))
        p[x,y]=(220,50,40,255)
    disc(im,8,8,1.1,STEEL_D)
    for i in range(5):
        a=math.radians(135+i*(270/4)); x=int(8+5.0*math.cos(a)); y=int(8+5.0*math.sin(a)); p[x,y]=STEEL_D+(255,)
    return im
for l in range(5): save(gauge(l),"meter_gauge_%d"%l)
im=plate(STEEL,seed=16); p=im.load()
for x in range(2,14): p[x,7]=TEAL_D+(255,); p[x,8]=TEAL+(255,)
save(im,"meter_side")

# Mixer
def mixer_side(f=None):
    im=plate(STEEL,seed=17,rivets=False); p=im.load()
    for y in range(3,13):
        for x in range(3,13):
            if x in (3,12) or y in (3,12): p[x,y]=STEEL_D+(255,); continue
            if f is None: p[x,y]=(WATER if x<8 else LAVA)+(255,)
            else:
                v=0.5+0.5*math.sin(0.9*x+1.4*math.sin(y*0.8+2*math.pi*f/8)-2*math.pi*f/8)
                p[x,y]=mix(WATER,LAVA,v)+(255,)
    return im
save(mixer_side(),"mixer_side"); save_anim([mixer_side(f) for f in range(8)],"mixer_side_on",2)
def mixer_top(f=None):
    im=plate(STEEL,seed=18); 
    if f is None: disc(im,8,8,5.5,STEEL_D); disc(im,8,8,1.8,STEEL_H); return im
    return swirl(f,8,(255,190,70),(40,90,200),5.6,base=im)
save(mixer_top(),"mixer_top"); save_anim([mixer_top(f) for f in range(8)],"mixer_top_on",2)
save(plate(STEEL_D,seed=19),"mixer_bottom")

# Dynamo
def dyn_front(f=None):
    im=plate(STEEL,seed=20); p=im.load()
    for y in range(5,14):
        for x in range(3,13):
            if f is None: p[x,y]=(26,18,16,255)
            else:
                v=hsh(x,(y+f*2)%16,9)+ (13-y)*0.07
                p[x,y]=mix((190,50,10),(255,220,90),max(0,min(1,v)))+(255,)
    for x in range(2,14): p[x,4]=COPPER_D+(255,)
    return im
save(dyn_front(),"dynamo_front"); save_anim([dyn_front(f) for f in range(8)],"dynamo_front_on",2)
im=plate(STEEL,seed=21); p=im.load()
for y in range(2,14,2):
    for x in range(2,14): p[x,y]=COPPER+(255,); p[x,y+1]=COPPER_D+(255,)
save(im,"dynamo_side")
im=plate(STEEL,seed=22); disc(im,8,8,6,STEEL_D); disc(im,8,8,5,STEEL_L,3.2); disc(im,8,8,1.6,COPPER_L); save(im,"dynamo_top")

# ---------------------------------------------------------------- Items
def core(f):
    im=new(); p=im.load(); pulse=0.5+0.5*math.sin(2*math.pi*f/8)
    for y in range(16):
        for x in range(16):
            dx,dy=x+0.5-8,y+0.5-8; d=abs(dx)/5.2+abs(dy)/6.4
            if d<=1:
                t=1-d; c=mix(TEAL_D,(190,255,245),t**1.2*(0.6+0.4*pulse)); p[x,y]=c+(255,)
            else:
                g=max(0,1-math.hypot(dx,dy)/9.0)*(0.25+0.45*pulse)
                if g>0.04: p[x,y]=TEAL+(cl(g*255),)
    for x,y in ((2,2),(3,2),(2,3),(13,2),(12,2),(13,3),(2,13),(3,13),(2,12),(13,13),(12,13),(13,12)):
        p[x,y]=STEEL_L+(255,)
    return im
save_anim([core(f) for f in range(8)],"flux_core",3,TI)
im=new(); p=im.load()
for t in range(0,11):
    x=3+t; y=13-t
    for dx,dy in ((0,0),(1,0)): p[x+dx,y+dy]=STEEL_L+(255,)
    p[x,y+1]=STEEL_D+(255,)
for t in range(3,8):
    x=3+t; y=13-t; p[x,y]=TEAL+(255,); p[x+1,y]=TEAL_D+(255,)
for dx,dy in ((10,2),(11,2),(12,2),(9,3),(13,3),(9,4),(13,4),(10,5),(12,5),(11,6)):
    p[dx+1 if dx>10 else dx,dy]=STEEL_H+(255,)
for dx,dy in ((11,3),(11,4)): p[dx,dy]=(0,0,0,0)
save(im,"flux_wrench",TI)
im=new(); p=im.load()
for y in range(2,15):
    for x in range(3,13):
        c=(22,86,92) if x>4 else (12,52,58)
        if y in (2,14) or x in (3,12): c=(8,36,42)
        p[x,y]=c+(255,)
for y in range(3,14): p[12,y]=(236,226,196,255); p[13,y]=(204,194,164,255)
for x in range(4,13): p[x,14]=(236,226,196,255); p[x,15]=(204,194,164,255)
for x,y in ((7,5),(8,5),(9,5),(7,6),(7,7),(8,7),(7,8),(7,9),(9,10),(10,10),(8,11)): p[x,y]=(255,196,70,255)
for x,y in ((6,4),(10,4)): p[x,y]=TEAL+(255,)
save(im,"field_manual",TI)
# Icon
ic=Image.new("RGBA",(64,64),(0,0,0,0)); c=core(2).resize((64,64),Image.NEAREST); ic.paste(c,(0,0)); ic.save(os.path.join(R,"icon.png"))
print("Texturen fertig")
