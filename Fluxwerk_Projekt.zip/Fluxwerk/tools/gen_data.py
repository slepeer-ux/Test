import json, os
BASE = os.path.join(os.path.dirname(__file__), "..", "src/main/resources")
A = BASE + "/assets/fluxwerk"; D = BASE + "/data/fluxwerk"
def w(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    json.dump(obj, open(path, "w"), ensure_ascii=False, indent=1)
T = lambda n: "fluxwerk:block/" + n
M = lambda n: {"model": "fluxwerk:block/" + n}
FL = ["none", "water", "lava", "milk"]
ROT = {"north": {}, "east": {"y": 90}, "south": {"y": 180}, "west": {"y": 270}, "up": {"x": 270}, "down": {"x": 90}}
def model(n, obj): w(f"{A}/models/block/{n}.json", obj)
def cube(n, up, down, north, south, east, west, particle=None):
    model(n, {"parent": "minecraft:block/cube", "textures": {"particle": particle or north, "up": T(up), "down": T(down),
            "north": T(north), "south": T(south), "east": T(east), "west": T(west)}})
def box(frm, to, tex="#t", faces=("down", "up", "north", "south", "west", "east")):
    return {"from": frm, "to": to, "faces": {f: {"texture": tex} for f in faces}}
def pm(n, tex, elements):
    model(n, {"parent": "minecraft:block/block", "textures": {"t": T(tex), "particle": T(tex)}, "elements": elements})

# ---- Rohre & Kabel
def conduit(name, lo, tex_for, states):
    hi = 16 - lo
    mp = []
    for s, tex in states:
        sfx = "" if s is None else "_" + s
        pm(f"{name}_center{sfx}", tex, [box([lo, lo, lo], [hi, hi, hi])])
        pm(f"{name}_arm{sfx}", tex, [box([lo, lo, 0], [hi, hi, lo], faces=("down", "up", "north", "west", "east"))])
        pm(f"{name}_item{sfx}", tex, [box([0, lo, lo], [16, hi, hi])])
    return mp
conduit("pipe", 5, None, [("none", "pipe"), ("water", "pipe_water"), ("lava", "pipe_lava"), ("milk", "pipe_milk")])
conduit("cable", 6, None, [("off", "cable"), ("lit", "cable_lit")])
def multipart(name, prop, vals):
    parts = []
    for v in vals:
        parts.append({"when": {prop: v}, "apply": M(f"{name}_center_{v}")})
        for d, rot in ROT.items():
            ap = dict(M(f"{name}_arm_{v}")); ap.update(rot)
            parts.append({"when": {prop: v, d: "true"}, "apply": ap})
    return {"multipart": parts}
w(f"{A}/blockstates/flux_pipe.json", multipart("pipe", "fluid", FL))
w(f"{A}/blockstates/flux_cable.json", multipart("cable", "lit", ["false", "true"]) if False else None) if False else None
# Kabel: lit true/false -> Modelle off/lit
parts = []
for v, sfx in (("false", "off"), ("true", "lit")):
    parts.append({"when": {"lit": v}, "apply": M(f"cable_center_{sfx}")})
    for d, rot in ROT.items():
        ap = dict(M(f"cable_arm_{sfx}")); ap.update(rot)
        parts.append({"when": {"lit": v, d: "true"}, "apply": ap})
w(f"{A}/blockstates/flux_cable.json", {"multipart": parts})

# ---- Tank
model_tex = {"none": None, "water": "fluid_water", "lava": "fluid_lava", "milk": "fluid_milk"}
variants = {}
for f in FL:
    for lvl in range(5):
        if f == "none" or lvl == 0:
            n = "tank_none"
            if not os.path.exists(f"{A}/models/block/tank_none.json"):
                model(n, {"parent": "minecraft:block/block", "textures": {"frame": T("tank"), "particle": T("tank")},
                          "elements": [box([0, 0, 0], [16, 16, 16], "#frame")]})
        else:
            n = f"tank_{f}_{lvl}"
            model(n, {"parent": "minecraft:block/block", "textures": {"frame": T("tank"), "fluid": T(model_tex[f]), "particle": T("tank")},
                      "elements": [box([0, 0, 0], [16, 16, 16], "#frame"),
                                   box([2, 1, 2], [14, 1 + 3 * lvl, 14], "#fluid")]})
        variants[f"fluid={f},level={lvl}"] = M(n)
w(f"{A}/blockstates/flux_tank.json", {"variants": variants})

# ---- Wuerfel-Maschinen mit Ausrichtung
def facing_lit(block, off, on):
    v = {}
    for lit, mn in (("false", off), ("true", on)):
        for d, rot in ROT.items():
            e = dict(M(mn)); e.update(rot)
            v[f"facing={d},lit={lit}"] = e
    w(f"{A}/blockstates/{block}.json", {"variants": v})
cube("pump", "pump_side", "pump_side", "pump_front", "pump_back", "pump_side", "pump_side")
cube("pump_on", "pump_side_on", "pump_side_on", "pump_front", "pump_back", "pump_side_on", "pump_side_on")
facing_lit("pressure_pump", "pump", "pump_on")
cube("suction", "suction_side", "suction_side", "suction_front", "suction_back", "suction_side", "suction_side")
cube("suction_on", "suction_side", "suction_side", "suction_front_on", "suction_back", "suction_side", "suction_side")
facing_lit("suction_unit", "suction", "suction_on")

# ---- Mixer, Dynamo (lit)
cube("mixer", "mixer_top", "mixer_bottom", "mixer_side", "mixer_side", "mixer_side", "mixer_side")
cube("mixer_on", "mixer_top_on", "mixer_bottom", "mixer_side_on", "mixer_side_on", "mixer_side_on", "mixer_side_on")
w(f"{A}/blockstates/fluid_mixer.json", {"variants": {"lit=false": M("mixer"), "lit=true": M("mixer_on")}})
cube("dynamo", "dynamo_top", "dynamo_top", "dynamo_front", "dynamo_side", "dynamo_side", "dynamo_side")
cube("dynamo_on", "dynamo_top", "dynamo_top", "dynamo_front_on", "dynamo_side", "dynamo_side", "dynamo_side")
w(f"{A}/blockstates/flux_dynamo.json", {"variants": {"lit=false": M("dynamo"), "lit=true": M("dynamo_on")}})

# ---- Ventil, Filter, Messgeraet
cube("valve_open", "valve_top_open", "valve_top_open", "valve_port", "valve_port", "valve_side", "valve_side")
cube("valve_closed", "valve_top_closed", "valve_top_closed", "valve_port", "valve_port", "valve_side", "valve_side")
w(f"{A}/blockstates/flux_valve.json", {"variants": {"open=true": M("valve_open"), "open=false": M("valve_closed")}})
for f in FL: cube(f"filter_{f}", f"filter_{f}", f"filter_{f}", f"filter_{f}", f"filter_{f}", f"filter_{f}", f"filter_{f}")
w(f"{A}/blockstates/flux_filter.json", {"variants": {f"fluid={f}": M(f"filter_{f}") for f in FL}})
for l in range(5): cube(f"meter_{l}", "meter_side", "meter_side", f"meter_gauge_{l}", f"meter_gauge_{l}", "meter_side", "meter_side")
w(f"{A}/blockstates/flux_meter.json", {"variants": {f"level={l}": M(f"meter_{l}") for l in range(5)}})

# ---- Item-Modelle
blocks = {"flux_pipe": "pipe_item_none", "flux_cable": "cable_item_off", "flux_tank": "tank_water_3", "suction_unit": "suction",
          "pressure_pump": "pump", "flux_valve": "valve_open", "flux_filter": "filter_none", "flux_meter": "meter_2",
          "fluid_mixer": "mixer", "flux_dynamo": "dynamo"}
for n, m in blocks.items(): w(f"{A}/models/item/{n}.json", {"parent": "fluxwerk:block/" + m})
w(f"{A}/models/item/flux_core.json", {"parent": "minecraft:item/generated", "textures": {"layer0": "fluxwerk:item/flux_core"}})
w(f"{A}/models/item/field_manual.json", {"parent": "minecraft:item/generated", "textures": {"layer0": "fluxwerk:item/field_manual"}})
w(f"{A}/models/item/flux_wrench.json", {"parent": "minecraft:item/handheld", "textures": {"layer0": "fluxwerk:item/flux_wrench"}})

# ---- Sprache
names = {"flux_pipe": "Flux-Rohr", "flux_cable": "Flux-Kabel", "flux_tank": "Flux-Tank", "suction_unit": "Saugeinheit",
         "pressure_pump": "Druckpumpe", "flux_valve": "Flux-Ventil", "flux_filter": "Flux-Filter", "flux_meter": "Flux-Messgerät",
         "fluid_mixer": "Flüssigkeitsmischer", "flux_dynamo": "Flux-Dynamo"}
items = {"flux_core": "Flux-Kern", "flux_wrench": "Flux-Schlüssel", "field_manual": "Fluxwerk-Handbuch"}
def lang(names, items, tr):
    d = {"itemGroup.fluxwerk.main": "Fluxwerk"}
    for k, v in names.items(): d["block.fluxwerk." + k] = v
    for k, v in items.items(): d["item.fluxwerk." + k] = v
    d.update(tr); return d
de = {"fluid.fluxwerk.none": "Leer", "fluid.fluxwerk.water": "Wasser", "fluid.fluxwerk.lava": "Lava", "fluid.fluxwerk.milk": "Milch",
      "hud.fluxwerk.fluid": "%s: %s / %s mB", "hud.fluxwerk.empty": "Leer: 0 / %s mB", "hud.fluxwerk.filter": "Filter: %s",
      "hud.fluxwerk.any": "alles", "hud.fluxwerk.energy": "Energie: %s / %s E", "hud.fluxwerk.use": "Verbrauch: %s E/s",
      "hud.fluxwerk.gen": "Erzeugung: +%s E/s", "hud.fluxwerk.idle": "Erzeugung: 0 E/s (aus)",
      "msg.fluxwerk.tank_cleared": "Tank geleert", "msg.fluxwerk.filter_set": "Filter: %s", "msg.fluxwerk.filter_cleared": "Filter gelöscht"}
en_names = {"flux_pipe": "Flux Pipe", "flux_cable": "Flux Cable", "flux_tank": "Flux Tank", "suction_unit": "Suction Unit",
            "pressure_pump": "Pressure Pump", "flux_valve": "Flux Valve", "flux_filter": "Flux Filter", "flux_meter": "Flux Meter",
            "fluid_mixer": "Fluid Mixer", "flux_dynamo": "Flux Dynamo"}
en_items = {"flux_core": "Flux Core", "flux_wrench": "Flux Wrench", "field_manual": "Fluxwerk Manual"}
en = {"fluid.fluxwerk.none": "Empty", "fluid.fluxwerk.water": "Water", "fluid.fluxwerk.lava": "Lava", "fluid.fluxwerk.milk": "Milk",
      "hud.fluxwerk.fluid": "%s: %s / %s mB", "hud.fluxwerk.empty": "Empty: 0 / %s mB", "hud.fluxwerk.filter": "Filter: %s",
      "hud.fluxwerk.any": "any", "hud.fluxwerk.energy": "Energy: %s / %s E", "hud.fluxwerk.use": "Usage: %s E/s",
      "hud.fluxwerk.gen": "Output: +%s E/s", "hud.fluxwerk.idle": "Output: 0 E/s (off)",
      "msg.fluxwerk.tank_cleared": "Tank emptied", "msg.fluxwerk.filter_set": "Filter: %s", "msg.fluxwerk.filter_cleared": "Filter cleared"}
w(f"{A}/lang/de_de.json", lang(names, items, de)); w(f"{A}/lang/en_us.json", lang(en_names, en_items, en))

# ---- Loot, Tags
for n in blocks:
    w(f"{D}/loot_table/blocks/{n}.json", {"type": "minecraft:block", "pools": [{"rolls": 1, "bonus_rolls": 0,
        "entries": [{"type": "minecraft:item", "name": "fluxwerk:" + n}], "conditions": [{"condition": "minecraft:survives_explosion"}]}]})
w(BASE + "/data/minecraft/tags/block/mineable/pickaxe.json", {"replace": False, "values": ["fluxwerk:" + n for n in blocks]})

# ---- Rezepte
def shaped(name, pattern, key, result, count=1):
    w(f"{D}/recipe/{name}.json", {"type": "minecraft:crafting_shaped", "category": "misc", "pattern": pattern,
      "key": {k: {"item": v} for k, v in key.items()}, "result": {"id": "fluxwerk:" + result, "count": count}})
I = "minecraft:iron_ingot"; C = "minecraft:copper_ingot"; R_ = "minecraft:redstone"; K = "fluxwerk:flux_core"; P = "fluxwerk:flux_pipe"
shaped("flux_core", ["IRI", "RLR", "IRI"], {"I": I, "R": R_, "L": "minecraft:lapis_lazuli"}, "flux_core")
shaped("flux_pipe", ["III", "GGG", "III"], {"I": I, "G": "minecraft:glass"}, "flux_pipe", 8)
shaped("flux_cable", ["CCC", "RRR", "CCC"], {"C": C, "R": R_}, "flux_cable", 6)
shaped("flux_tank", ["IGI", "GBG", "IGI"], {"I": I, "G": "minecraft:glass", "B": "minecraft:bucket"}, "flux_tank")
shaped("suction_unit", ["IHI", "ICI"], {"I": I, "H": "minecraft:hopper", "C": K}, "suction_unit")
shaped("pressure_pump", ["IPI", "ICI"], {"I": I, "P": "minecraft:piston", "C": K}, "pressure_pump")
shaped("flux_valve", [" L ", "IPI"], {"I": I, "L": "minecraft:lever", "P": P}, "flux_valve")
shaped("flux_filter", [" B ", "IPI"], {"I": I, "B": "minecraft:iron_bars", "P": P}, "flux_filter")
shaped("flux_meter", [" M ", "IPI"], {"I": I, "M": "minecraft:comparator", "P": P}, "flux_meter")
shaped("fluid_mixer", ["PCP", "IUI"], {"I": I, "P": P, "C": K, "U": "minecraft:cauldron"}, "fluid_mixer")
shaped("flux_dynamo", ["CKC", "CFC", "III"], {"C": C, "K": K, "F": "minecraft:furnace", "I": I}, "flux_dynamo")
shaped("flux_wrench", ["I I", " C ", " I "], {"I": I, "C": K}, "flux_wrench")
w(f"{D}/recipe/field_manual.json", {"type": "minecraft:crafting_shapeless", "category": "misc",
   "ingredients": [{"item": "minecraft:book"}, {"item": "fluxwerk:flux_core"}], "result": {"id": "fluxwerk:field_manual", "count": 1}})
print("Daten fertig")
