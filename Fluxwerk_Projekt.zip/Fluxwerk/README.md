# Fluxwerk 0.2.0 (Minecraft 1.21.1, Fabric)

## Jar bauen (kostenlos, ohne Installation)
1. Auf github.com kostenloses Konto anlegen, "New repository" (public), Namen z. B. "fluxwerk".
2. "uploading an existing file" klicken und ALLE Dateien dieses Ordners hineinziehen (auch den versteckten Ordner `.github`).
   Falls `.github` fehlt: "Add file > Create new file", Name `.github/workflows/build.yml`, Inhalt aus `BUILD_WORKFLOW.txt` einfügen.
3. Oben auf "Actions" klicken. Der Bau startet automatisch (ca. 3-5 Minuten).
4. Fertigen Lauf anklicken, unten bei "Artifacts" `Fluxwerk-jar` herunterladen, entpacken -> `fluxwerk-0.2.0.jar`.
5. Bei einem Fehler: Log kopieren und an Claude schicken.

## Installieren
Server UND jeder Spieler brauchen: Fabric Loader (>=0.16.5), Fabric API (0.102.1+1.21.1) und `fluxwerk-0.2.0.jar` im Ordner `mods`.

Im Spiel: `/fluxwerk handbuch` gibt das Handbuch.
