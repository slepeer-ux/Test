package de.fluxwerk;

import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Gemeinsame Basis aller Fluxwerk-Bloecke. */
public abstract class FluxBlock extends Block implements BlockEntityProvider {
    public static final EnumProperty<FluidKind> FLUID = EnumProperty.of("fluid", FluidKind.class);
    public static final IntProperty LEVEL = IntProperty.of("level", 0, 4);

    public final Role role;

    protected FluxBlock(Settings settings, Role role) {
        super(settings);
        this.role = role;
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new FluxBE(pos, state);
    }

    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState state, BlockEntityType<T> type) {
        if (world.isClient || type != Fluxwerk.FLUX_BE) return null;
        return (w, p, s, be) -> FluxBE.tick(w, p, s, (FluxBE) be);
    }

    /** Wie soll der Block aussehen, abhaengig vom Zustand der Block-Entity? */
    public BlockState visual(BlockState st, FluxBE be, boolean active) {
        return st;
    }

    /** Rechtsklick mit dem Flux-Schluessel. */
    public ActionResult wrench(World world, BlockPos pos, BlockState state, PlayerEntity player) {
        return ActionResult.PASS;
    }

    @Override
    public boolean hasComparatorOutput(BlockState state) {
        return role == Role.TANK || role == Role.METER;
    }

    @Override
    public int getComparatorOutput(BlockState state, World world, BlockPos pos) {
        BlockEntity be = world.getBlockEntity(pos);
        if (be instanceof FluxBE) return ((FluxBE) be).comparator();
        return 0;
    }

    /** Eimer: Tank, Mixer und Dynamo nehmen volle Eimer an, Tanks geben Eimer ab. */
    @Override
    public ItemActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos,
                                          PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (role != Role.TANK && role != Role.MIXER && role != Role.DYNAMO) {
            return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        FluidKind bucket = FluidKind.ofBucket(stack);
        boolean empty = stack.isOf(Items.BUCKET);
        if (bucket == FluidKind.NONE && !empty) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (empty && role != Role.TANK) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (world.isClient) return ItemActionResult.SUCCESS;
        BlockEntity be = world.getBlockEntity(pos);
        if (!(be instanceof FluxBE)) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        FluxBE f = (FluxBE) be;
        if (bucket != FluidKind.NONE) {
            if (f.space(bucket) < 1000) return ItemActionResult.FAIL;
            f.accept(bucket, 1000, hit.getSide());
            player.setStackInHand(hand, ItemUsage.exchangeStack(stack, player, new ItemStack(Items.BUCKET)));
            world.playSound(null, pos, bucket == FluidKind.LAVA ? SoundEvents.ITEM_BUCKET_EMPTY_LAVA : SoundEvents.ITEM_BUCKET_EMPTY,
                    SoundCategory.BLOCKS, 1f, 1f);
        } else {
            if (f.amount < 1000) return ItemActionResult.FAIL;
            FluidKind k = f.fluid;
            f.drain(1000);
            player.setStackInHand(hand, ItemUsage.exchangeStack(stack, player, new ItemStack(k.bucket())));
            world.playSound(null, pos, k == FluidKind.LAVA ? SoundEvents.ITEM_BUCKET_FILL_LAVA : SoundEvents.ITEM_BUCKET_FILL,
                    SoundCategory.BLOCKS, 1f, 1f);
        }
        f.sync();
        return ItemActionResult.CONSUME;
    }
}
