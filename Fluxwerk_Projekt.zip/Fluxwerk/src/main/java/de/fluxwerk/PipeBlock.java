package de.fluxwerk;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.state.StateManager;

public class PipeBlock extends ConduitBlock {
    public static final MapCodec<PipeBlock> CODEC = createCodec(PipeBlock::new);

    public PipeBlock(Settings settings) {
        super(settings, Role.PIPE, 5);
        setDefaultState(noConnections(getDefaultState()).with(FLUID, FluidKind.NONE));
    }

    @Override
    public MapCodec<PipeBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        super.appendProperties(builder);
        builder.add(FLUID);
    }

    @Override
    public BlockState visual(BlockState st, FluxBE be, boolean active) {
        FluidKind cur = st.get(FLUID);
        FluidKind want = cur;
        if (cur == FluidKind.NONE) {
            if (be.amount >= 100) want = be.fluid;
        } else if (be.amount < 10) {
            want = FluidKind.NONE;
        } else {
            want = be.fluid;
        }
        return want == cur ? st : st.with(FLUID, want);
    }
}
