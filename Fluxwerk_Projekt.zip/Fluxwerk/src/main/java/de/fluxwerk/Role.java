package de.fluxwerk;

import net.minecraft.block.BlockState;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.Direction;

/** Beschreibt, was ein Fluxwerk-Block kann (Fassungsvermögen, Energie, Anschlussseiten). */
public enum Role {
    //   Fluessigkeit(mB), Energie(E), Verbrauch(E/s)
    PIPE(1000, 0, 0),
    CABLE(0, 2000, 0),
    TANK(8000, 0, 0),
    SUCTION(1000, 400, 50),
    PUMP(1000, 400, 50),
    VALVE(1000, 0, 0),
    FILTER(1000, 0, 0),
    METER(1000, 0, 0),
    MIXER(2000, 1000, 25),
    DYNAMO(1000, 4000, 0);

    public final int fluidCap;
    public final int energyCap;
    public final int energyUse;

    Role(int fluidCap, int energyCap, int energyUse) {
        this.fluidCap = fluidCap;
        this.energyCap = energyCap;
        this.energyUse = energyUse;
    }

    public boolean pushesFluid() {
        return fluidCap > 0 && this != DYNAMO && this != MIXER;
    }

    public boolean pushesEnergy() {
        return this == CABLE || this == DYNAMO;
    }

    /** Hat dieser Block an der Seite einen Fluessigkeitsanschluss? */
    public boolean fluidSide(BlockState st, Direction side) {
        if (fluidCap <= 0) return false;
        if (st.contains(Properties.FACING)) {
            Direction f = st.get(Properties.FACING);
            if (this == PUMP) return side == f || side == f.getOpposite();
            if (this == SUCTION) return side != f;
        }
        return true;
    }

    public boolean energySide(BlockState st, Direction side) {
        return energyCap > 0;
    }
}
