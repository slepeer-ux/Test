package de.fluxwerk;

import com.mojang.serialization.MapCodec;

/** Fluessigkeitsmischer: 1000 mB Wasser + 1000 mB Lava + Energie = Obsidian. */
public class MixerBlock extends ProcessBlock {
    public static final MapCodec<MixerBlock> CODEC = createCodec(MixerBlock::new);

    public MixerBlock(Settings settings) {
        super(settings, Role.MIXER);
    }

    @Override
    public MapCodec<MixerBlock> getCodec() {
        return CODEC;
    }
}
