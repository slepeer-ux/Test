package de.fluxwerk;

import com.mojang.serialization.MapCodec;

/** Flux-Dynamo: verbrennt Lava zu Energie. */
public class DynamoBlock extends ProcessBlock {
    public static final MapCodec<DynamoBlock> CODEC = createCodec(DynamoBlock::new);

    public DynamoBlock(Settings settings) {
        super(settings, Role.DYNAMO);
    }

    @Override
    public MapCodec<DynamoBlock> getCodec() {
        return CODEC;
    }
}
