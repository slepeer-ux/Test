package de.fluxwerk;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.List;

public final class FluxwerkClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlock(Fluxwerk.TANK, RenderLayer.getCutout());
        HudRenderCallback.EVENT.register(FluxwerkClient::renderHud);
    }

    private static void renderHud(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        HitResult hr = mc.crosshairTarget;
        if (!(hr instanceof BlockHitResult) || hr.getType() != HitResult.Type.BLOCK) return;
        BlockEntity be = mc.world.getBlockEntity(((BlockHitResult) hr).getBlockPos());
        if (!(be instanceof FluxBE)) return;
        FluxBE f = (FluxBE) be;
        boolean wrench = mc.player.getMainHandStack().isOf(Fluxwerk.WRENCH) || mc.player.getOffHandStack().isOf(Fluxwerk.WRENCH);
        List<Text> lines = f.hudLines(wrench);
        if (lines.isEmpty()) return;
        float frac = f.barFraction();
        boolean bar = frac >= 0f && (wrench || f.role() == Role.TANK);

        TextRenderer tr = mc.textRenderer;
        int w = 60;
        for (Text t : lines) w = Math.max(w, tr.getWidth(t));
        int h = lines.size() * 10 + (bar ? 8 : 0);
        int x = ctx.getScaledWindowWidth() / 2 + 18;
        int y = ctx.getScaledWindowHeight() / 2 - h / 2;

        ctx.fill(x - 6, y - 4, x + w + 5, y + h + 3, 0xC0121A24);
        ctx.fill(x - 6, y - 4, x - 4, y + h + 3, 0xFF2EE6C8);
        for (int i = 0; i < lines.size(); i++) {
            ctx.drawTextWithShadow(tr, lines.get(i), x, y + i * 10, 0xFFFFFFFF);
        }
        if (bar) {
            int by = y + lines.size() * 10 + 1;
            ctx.fill(x, by, x + w, by + 5, 0xFF000000);
            ctx.fill(x + 1, by + 1, x + 1 + (int) ((w - 2) * frac), by + 4, f.fluid.color);
        }
    }
}
