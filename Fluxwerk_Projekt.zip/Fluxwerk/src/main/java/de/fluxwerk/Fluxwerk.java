package de.fluxwerk;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.MapColor;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.dispenser.DispenserBehavior;
import net.minecraft.block.dispenser.ItemDispenserBehavior;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPointer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.server.world.ServerWorld;

public final class Fluxwerk implements ModInitializer {
    public static final String ID = "fluxwerk";
    public static final String MANUAL_TAG = "fluxwerk_manual_given";

    public static Block PIPE, CABLE, TANK, SUCTION, PUMP, VALVE, FILTER, METER, MIXER, DYNAMO;
    public static Item FLUX_CORE, WRENCH, FIELD_MANUAL;
    public static BlockEntityType<FluxBE> FLUX_BE;

    public static Identifier id(String path) {
        return Identifier.of(ID, path);
    }

    private static int light(BlockState s) {
        if (s.contains(Properties.LIT) && s.get(Properties.LIT)) return 8;
        if (s.contains(FluxBlock.FLUID) && s.get(FluxBlock.FLUID) == FluidKind.LAVA) return 10;
        return 0;
    }

    private static AbstractBlock.Settings thin(MapColor c) {
        return AbstractBlock.Settings.create().mapColor(c).strength(2.0f, 6.0f).sounds(BlockSoundGroup.METAL)
                .nonOpaque().luminance(Fluxwerk::light);
    }

    private static AbstractBlock.Settings solid(MapColor c) {
        return AbstractBlock.Settings.create().mapColor(c).strength(3.0f, 6.0f).sounds(BlockSoundGroup.METAL)
                .luminance(Fluxwerk::light);
    }

    private static <B extends Block> B block(String name, B block) {
        Registry.register(Registries.BLOCK, id(name), block);
        Registry.register(Registries.ITEM, id(name), new BlockItem(block, new Item.Settings()));
        return block;
    }

    @Override
    public void onInitialize() {
        PIPE = block("flux_pipe", new PipeBlock(thin(MapColor.IRON_GRAY)));
        CABLE = block("flux_cable", new CableBlock(thin(MapColor.ORANGE)));
        TANK = block("flux_tank", new TankBlock(thin(MapColor.IRON_GRAY)));
        SUCTION = block("suction_unit", new SuctionBlock(solid(MapColor.TEAL)));
        PUMP = block("pressure_pump", new PumpBlock(solid(MapColor.TEAL)));
        VALVE = block("flux_valve", new ValveBlock(solid(MapColor.IRON_GRAY)));
        FILTER = block("flux_filter", new FilterBlock(solid(MapColor.IRON_GRAY)));
        METER = block("flux_meter", new MeterBlock(solid(MapColor.IRON_GRAY)));
        MIXER = block("fluid_mixer", new MixerBlock(solid(MapColor.TEAL)));
        DYNAMO = block("flux_dynamo", new DynamoBlock(solid(MapColor.ORANGE)));

        FLUX_CORE = Registry.register(Registries.ITEM, id("flux_core"), new Item(new Item.Settings()));
        WRENCH = Registry.register(Registries.ITEM, id("flux_wrench"), new WrenchItem(new Item.Settings().maxCount(1)));
        FIELD_MANUAL = Registry.register(Registries.ITEM, id("field_manual"), new FieldManualItem(new Item.Settings().maxCount(1)));

        FLUX_BE = Registry.register(Registries.BLOCK_ENTITY_TYPE, id("flux"),
                BlockEntityType.Builder.create(FluxBE::new, PIPE, CABLE, TANK, SUCTION, PUMP, VALVE, FILTER, METER, MIXER, DYNAMO).build());

        Registry.register(Registries.ITEM_GROUP, id("main"), FabricItemGroup.builder()
                .icon(() -> new ItemStack(FLUX_CORE))
                .displayName(Text.translatable("itemGroup.fluxwerk.main"))
                .entries((ctx, entries) -> {
                    entries.add(FIELD_MANUAL);
                    entries.add(WRENCH);
                    entries.add(FLUX_CORE);
                    entries.add(PIPE);
                    entries.add(TANK);
                    entries.add(SUCTION);
                    entries.add(PUMP);
                    entries.add(VALVE);
                    entries.add(FILTER);
                    entries.add(METER);
                    entries.add(MIXER);
                    entries.add(DYNAMO);
                    entries.add(CABLE);
                }).build());

        // Handbuch beim ersten Beitritt
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.player;
            if (!p.getCommandTags().contains(MANUAL_TAG)) {
                p.addCommandTag(MANUAL_TAG);
                Manual.give(p);
            }
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(CommandManager.literal("fluxwerk")
                        .then(CommandManager.literal("handbuch").executes(ctx -> {
                            Manual.give(ctx.getSource().getPlayerOrThrow());
                            return 1;
                        }))));

        // Spender (Dispenser) mit Eimern arbeitet mit Tanks
        wrapDispenser(Items.BUCKET);
        wrapDispenser(Items.WATER_BUCKET);
        wrapDispenser(Items.LAVA_BUCKET);
        wrapDispenser(Items.MILK_BUCKET);
    }

    private static void wrapDispenser(Item item) {
        DispenserBehavior previous = DispenserBlock.BEHAVIORS.get(item);
        DispenserBlock.registerBehavior(item, (pointer, stack) -> {
            ItemStack result = dispenseIntoTank(pointer, stack);
            return result != null ? result : previous.dispense(pointer, stack);
        });
    }

    /** Gibt null zurueck, wenn vor dem Spender kein passender Tank steht. */
    private static ItemStack dispenseIntoTank(BlockPointer pointer, ItemStack stack) {
        Direction dir = pointer.state().get(DispenserBlock.FACING);
        ServerWorld w = pointer.world();
        BlockPos tp = pointer.pos().offset(dir);
        BlockEntity be = w.getBlockEntity(tp);
        if (!(be instanceof FluxBE)) return null;
        FluxBE f = (FluxBE) be;
        Role r = f.role();
        if (r != Role.TANK && r != Role.MIXER && r != Role.DYNAMO) return null;

        ItemStack out;
        if (stack.isOf(Items.BUCKET)) {
            if (r != Role.TANK || f.amount < 1000) return null;
            FluidKind k = f.fluid;
            f.drain(1000);
            out = new ItemStack(k.bucket());
            w.playSound(null, tp, SoundEvents.ITEM_BUCKET_FILL, SoundCategory.BLOCKS, 1f, 1f);
        } else {
            FluidKind k = FluidKind.ofBucket(stack);
            if (k == FluidKind.NONE || f.space(k) < 1000) return null;
            f.accept(k, 1000, dir.getOpposite());
            out = new ItemStack(Items.BUCKET);
            w.playSound(null, tp, SoundEvents.ITEM_BUCKET_EMPTY, SoundCategory.BLOCKS, 1f, 1f);
        }
        f.sync();

        if (stack.getCount() == 1) return out;
        stack.decrement(1);
        if (pointer.blockEntity().addToFirstFreeSlot(out) < 0) {
            new ItemDispenserBehavior().dispense(pointer, out);
        }
        return stack;
    }
}
