package de.fluxwerk;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Gemeinsame Basis fuer Pumpe und Saugeinheit (haben eine Ausrichtung und eine Aktiv-Anzeige). */
public abstract class MachineBlock extends FluxBlock {
    protected MachineBlock(Settings settings, Role role) {
        super(settings, role);
        setDefaultState(getDefaultState().with(Properties.FACING, net.minecraft.util.math.Direction.NORTH).with(Properties.LIT, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(Properties.FACING, Properties.LIT);
    }

    @Override
    public BlockState visual(BlockState st, FluxBE be, boolean active) {
        return st.get(Properties.LIT) == be.lit ? st : st.with(Properties.LIT, be.lit);
    }

    /** Schluessel: Ausrichtung weiterdrehen. */
    @Override
    public ActionResult wrench(World world, BlockPos pos, BlockState state, PlayerEntity player) {
        if (!world.isClient) {
            world.setBlockState(pos, state.cycle(Properties.FACING), Block.NOTIFY_ALL);
        }
        return ActionResult.SUCCESS;
    }
}
