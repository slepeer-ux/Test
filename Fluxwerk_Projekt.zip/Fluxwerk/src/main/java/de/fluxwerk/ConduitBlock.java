package de.fluxwerk;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import net.minecraft.block.ShapeContext;

import java.util.concurrent.ConcurrentHashMap;

/** Rohre und Kabel: verbinden sich automatisch mit Nachbarn. */
public abstract class ConduitBlock extends FluxBlock {
    private static final ConcurrentHashMap<Integer, VoxelShape> SHAPES = new ConcurrentHashMap<>();

    private final int lo;
    private final boolean fluidConduit;

    protected ConduitBlock(Settings settings, Role role, int lo) {
        super(settings, role);
        this.lo = lo;
        this.fluidConduit = role.fluidCap > 0;
    }

    public static BooleanProperty prop(Direction d) {
        switch (d) {
            case NORTH: return Properties.NORTH;
            case EAST: return Properties.EAST;
            case SOUTH: return Properties.SOUTH;
            case WEST: return Properties.WEST;
            case UP: return Properties.UP;
            default: return Properties.DOWN;
        }
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(Properties.NORTH, Properties.EAST, Properties.SOUTH, Properties.WEST, Properties.UP, Properties.DOWN);
    }

    protected BlockState noConnections(BlockState s) {
        for (Direction d : Direction.values()) s = s.with(prop(d), false);
        return s;
    }

    protected boolean connects(BlockView world, BlockPos pos, Direction d) {
        BlockState ns = world.getBlockState(pos.offset(d));
        if (!(ns.getBlock() instanceof FluxBlock)) return false;
        Role nr = ((FluxBlock) ns.getBlock()).role;
        Direction back = d.getOpposite();
        return fluidConduit ? nr.fluidSide(ns, back) : nr.energySide(ns, back);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        BlockState s = getDefaultState();
        for (Direction d : Direction.values()) s = s.with(prop(d), connects(ctx.getWorld(), ctx.getBlockPos(), d));
        return s;
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState state, Direction direction, BlockState neighborState,
                                                WorldAccess world, BlockPos pos, BlockPos neighborPos) {
        return state.with(prop(direction), connects(world, pos, direction));
    }

    @Override
    public VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext ctx) {
        int mask = 0;
        for (Direction d : Direction.values()) {
            if (state.get(prop(d))) mask |= 1 << d.getId();
        }
        final int l = lo;
        final int m = mask;
        return SHAPES.computeIfAbsent(l * 64 + m, key -> {
            int h = 16 - l;
            VoxelShape s = Block.createCuboidShape(l, l, l, h, h, h);
            for (Direction d : Direction.values()) {
                if ((m & (1 << d.getId())) != 0) s = VoxelShapes.union(s, arm(d, l, h));
            }
            return s;
        });
    }

    private static VoxelShape arm(Direction d, int lo, int hi) {
        switch (d) {
            case NORTH: return Block.createCuboidShape(lo, lo, 0, hi, hi, lo);
            case SOUTH: return Block.createCuboidShape(lo, lo, hi, hi, hi, 16);
            case WEST: return Block.createCuboidShape(0, lo, lo, lo, hi, hi);
            case EAST: return Block.createCuboidShape(hi, lo, lo, 16, hi, hi);
            case DOWN: return Block.createCuboidShape(lo, 0, lo, hi, lo, hi);
            default: return Block.createCuboidShape(lo, hi, lo, hi, 16, hi);
        }
    }
}
