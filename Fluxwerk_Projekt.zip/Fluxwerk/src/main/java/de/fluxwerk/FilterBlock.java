package de.fluxwerk;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Filter: laesst nur eine Fluessigkeit durch. Mit vollem Eimer einstellen, Schluessel + Schleichen loescht. */
public class FilterBlock extends FluxBlock {
    public static final MapCodec<FilterBlock> CODEC = createCodec(FilterBlock::new);

    public FilterBlock(Settings settings) {
        super(settings, Role.FILTER);
        setDefaultState(getDefaultState().with(FLUID, FluidKind.NONE));
    }

    @Override
    public MapCodec<FilterBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FLUID);
    }

    @Override
    public ItemActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos,
                                          PlayerEntity player, Hand hand, BlockHitResult hit) {
        FluidKind k = FluidKind.ofBucket(stack);
        if (k == FluidKind.NONE) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (!world.isClient) {
            world.setBlockState(pos, state.with(FLUID, k), Block.NOTIFY_ALL);
            world.playSound(null, pos, SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, SoundCategory.BLOCKS, 1f, 1f);
            player.sendMessage(Text.translatable("msg.fluxwerk.filter_set", k.displayName()), true);
        }
        return ItemActionResult.success(world.isClient);
    }

    @Override
    public ActionResult wrench(World world, BlockPos pos, BlockState state, PlayerEntity player) {
        if (!player.isSneaking()) return ActionResult.PASS;
        if (!world.isClient) {
            world.setBlockState(pos, state.with(FLUID, FluidKind.NONE), Block.NOTIFY_ALL);
            player.sendMessage(Text.translatable("msg.fluxwerk.filter_cleared"), true);
        }
        return ActionResult.SUCCESS;
    }
}
