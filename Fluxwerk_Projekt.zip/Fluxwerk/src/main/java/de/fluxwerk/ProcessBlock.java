package de.fluxwerk;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;

/** Mixer und Dynamo: nur eine Aktiv-Anzeige. */
public abstract class ProcessBlock extends FluxBlock {
    protected ProcessBlock(Settings settings, Role role) {
        super(settings, role);
        setDefaultState(getDefaultState().with(Properties.LIT, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(Properties.LIT);
    }

    @Override
    public BlockState visual(BlockState st, FluxBE be, boolean active) {
        return st.get(Properties.LIT) == be.lit ? st : st.with(Properties.LIT, be.lit);
    }
}
