package de.fluxwerk;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.property.Properties;

/** Druckpumpe: saugt hinten an, drueckt vorne heraus (Pfeilrichtung = Blickrichtung beim Setzen). */
public class PumpBlock extends MachineBlock {
    public static final MapCodec<PumpBlock> CODEC = createCodec(PumpBlock::new);

    public PumpBlock(Settings settings) {
        super(settings, Role.PUMP);
    }

    @Override
    public MapCodec<PumpBlock> getCodec() {
        return CODEC;
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        return getDefaultState().with(Properties.FACING, ctx.getPlayerLookDirection());
    }
}
