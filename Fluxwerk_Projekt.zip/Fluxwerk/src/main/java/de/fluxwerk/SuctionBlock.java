package de.fluxwerk;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.property.Properties;

/** Saugeinheit: Mund zeigt auf den Block, an den sie gesetzt wird (Tank, Kessel, Wasser-/Lavaquelle). */
public class SuctionBlock extends MachineBlock {
    public static final MapCodec<SuctionBlock> CODEC = createCodec(SuctionBlock::new);

    public SuctionBlock(Settings settings) {
        super(settings, Role.SUCTION);
    }

    @Override
    public MapCodec<SuctionBlock> getCodec() {
        return CODEC;
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        return getDefaultState().with(Properties.FACING, ctx.getSide().getOpposite());
    }
}
