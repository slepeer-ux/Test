package de.fluxwerk;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Ventil: Redstone-Signal schliesst es. */
public class ValveBlock extends FluxBlock {
    public static final MapCodec<ValveBlock> CODEC = createCodec(ValveBlock::new);

    public ValveBlock(Settings settings) {
        super(settings, Role.VALVE);
        setDefaultState(getDefaultState().with(Properties.OPEN, true));
    }

    @Override
    public MapCodec<ValveBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(Properties.OPEN);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext ctx) {
        return getDefaultState().with(Properties.OPEN, !ctx.getWorld().isReceivingRedstonePower(ctx.getBlockPos()));
    }

    @Override
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, BlockPos sourcePos, boolean notify) {
        if (world.isClient) return;
        boolean open = !world.isReceivingRedstonePower(pos);
        if (open != state.get(Properties.OPEN)) {
            world.setBlockState(pos, state.with(Properties.OPEN, open), Block.NOTIFY_LISTENERS);
        }
    }
}
