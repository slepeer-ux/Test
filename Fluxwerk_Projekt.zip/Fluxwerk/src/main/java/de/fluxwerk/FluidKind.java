package de.fluxwerk;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.StringIdentifiable;

public enum FluidKind implements StringIdentifiable {
    NONE("none", 0xFF202830),
    WATER("water", 0xFF3F76E4),
    LAVA("lava", 0xFFFF7A18),
    MILK("milk", 0xFFF2F2EA);

    public final String id;
    public final int color;

    FluidKind(String id, int color) {
        this.id = id;
        this.color = color;
    }

    @Override
    public String asString() {
        return id;
    }

    public Text displayName() {
        return Text.translatable("fluid.fluxwerk." + id);
    }

    public Item bucket() {
        switch (this) {
            case WATER: return Items.WATER_BUCKET;
            case LAVA: return Items.LAVA_BUCKET;
            case MILK: return Items.MILK_BUCKET;
            default: return Items.BUCKET;
        }
    }

    public static FluidKind fromId(String s) {
        for (FluidKind k : values()) {
            if (k.id.equals(s)) return k;
        }
        return NONE;
    }

    public static FluidKind ofBucket(ItemStack s) {
        if (s.isOf(Items.WATER_BUCKET)) return WATER;
        if (s.isOf(Items.LAVA_BUCKET)) return LAVA;
        if (s.isOf(Items.MILK_BUCKET)) return MILK;
        return NONE;
    }
}
