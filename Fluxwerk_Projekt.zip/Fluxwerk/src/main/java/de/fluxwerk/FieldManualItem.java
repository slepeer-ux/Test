package de.fluxwerk;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Handbuch-Item (craftbar): Rechtsklick wandelt es in das lesbare Buch um. */
public class FieldManualItem extends Item {
    public FieldManualItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity) {
            Manual.give((ServerPlayerEntity) user);
            if (!user.isCreative()) stack.decrement(1);
        }
        return TypedActionResult.success(stack, world.isClient);
    }
}
