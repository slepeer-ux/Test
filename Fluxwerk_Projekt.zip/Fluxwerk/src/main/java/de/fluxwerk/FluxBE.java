package de.fluxwerk;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * Eine einzige Block-Entity fuer alle Fluxwerk-Maschinen.
 * Alle 4 Ticks wird ein "Schritt" berechnet (leichtgewichtig, kein Lag).
 */
public class FluxBE extends BlockEntity {
    public static final int STEP = 4;
    public static final int FLUID_FLOW = 250;   // mB pro Schritt zwischen Rohren
    public static final int ENERGY_FLOW = 400;  // E pro Schritt zwischen Kabeln

    public FluidKind fluid = FluidKind.NONE;
    public int amount;     // mB im Hauptpuffer
    public int energy;     // E
    public int mixWater;   // Mixer
    public int mixLava;    // Mixer
    public int burn;       // Dynamo: Restschritte
    public int progress;   // Mixer: Fortschritt
    public boolean lit;

    private int timer;
    private int litLeft;
    private int moved;
    private boolean dirtyFlag;
    private boolean netDirty;

    public FluxBE(BlockPos pos, BlockState state) {
        super(Fluxwerk.FLUX_BE, pos, state);
    }

    public Role role() {
        BlockState st = getCachedState();
        if (st.getBlock() instanceof FluxBlock) return ((FluxBlock) st.getBlock()).role;
        return Role.PIPE;
    }

    private void changed() {
        dirtyFlag = true;
    }

    /** Sofort speichern und an Clients schicken (nach Spieler-Interaktion). */
    public void sync() {
        markDirty();
        if (world != null && !world.isClient) {
            BlockState s = world.getBlockState(pos);
            world.updateListeners(pos, s, s, Block.NOTIFY_LISTENERS);
        }
        dirtyFlag = false;
        netDirty = false;
    }

    // ---------------------------------------------------------------- Fluessigkeiten

    public int space(FluidKind k) {
        Role r = role();
        if (k == FluidKind.NONE || r.fluidCap <= 0) return 0;
        switch (r) {
            case MIXER:
                if (k == FluidKind.WATER) return r.fluidCap - mixWater;
                if (k == FluidKind.LAVA) return r.fluidCap - mixLava;
                return 0;
            case DYNAMO:
                if (k != FluidKind.LAVA) return 0;
                return r.fluidCap - amount;
            default:
                if (amount > 0 && fluid != k) return 0;
                return r.fluidCap - amount;
        }
    }

    /** Nimmt Fluessigkeit an. Gibt zurueck, wie viel wirklich aufgenommen wurde. */
    public int accept(FluidKind k, int max, Direction side) {
        Role r = role();
        BlockState st = getCachedState();
        if (k == FluidKind.NONE || max <= 0 || r.fluidCap <= 0) return 0;
        if (!r.fluidSide(st, side)) return 0;
        if (r == Role.PUMP || r == Role.SUCTION) return 0;
        if (r == Role.VALVE && !st.get(Properties.OPEN)) return 0;
        if (r == Role.FILTER) {
            FluidKind f = st.get(FluxBlock.FLUID);
            if (f != FluidKind.NONE && f != k) return 0;
        }
        int a = Math.min(max, space(k));
        if (a <= 0) return 0;
        if (r == Role.MIXER) {
            if (k == FluidKind.WATER) mixWater += a; else mixLava += a;
        } else {
            fluid = k;
            amount += a;
        }
        changed();
        return a;
    }

    public int drain(int max) {
        int a = Math.min(max, amount);
        if (a <= 0) return 0;
        amount -= a;
        if (amount <= 0) {
            amount = 0;
            fluid = FluidKind.NONE;
        }
        changed();
        return a;
    }

    public boolean canDrain(Direction side) {
        Role r = role();
        BlockState st = getCachedState();
        if (r.fluidCap <= 0 || r == Role.DYNAMO || r == Role.MIXER) return false;
        if (!r.fluidSide(st, side)) return false;
        if (r == Role.VALVE && !st.get(Properties.OPEN)) return false;
        return true;
    }

    public int acceptEnergy(int max) {
        Role r = role();
        if (r.energyCap <= 0 || r == Role.DYNAMO) return 0;
        int a = Math.min(max, r.energyCap - energy);
        if (a <= 0) return 0;
        energy += a;
        changed();
        return a;
    }

    public int comparator() {
        Role r = role();
        if (r.fluidCap <= 0 || amount <= 0) return 0;
        return Math.min(15, (amount * 15 + r.fluidCap - 1) / r.fluidCap);
    }

    // ---------------------------------------------------------------- Server-Tick

    public static void tick(World world, BlockPos pos, BlockState state, FluxBE be) {
        if (world instanceof ServerWorld) be.serverTick((ServerWorld) world, pos);
    }

    private void serverTick(ServerWorld w, BlockPos pos) {
        timer++;
        if (timer % STEP != 0) return;
        BlockState st = getCachedState();
        Role r = role();
        moved = 0;
        boolean active = false;
        switch (r) {
            case DYNAMO: active = dynamo(); break;
            case SUCTION: active = suction(w, pos, st); break;
            case PUMP: active = pump(w, pos, st); break;
            case MIXER: active = mixer(w, pos); break;
            default: break;
        }
        if (r != Role.PUMP && r != Role.SUCTION && r.pushesFluid() && amount > 0) pushFluid(w, pos, st, r);
        if (r.pushesEnergy() && energy > 0) pushEnergy(w, pos, r);

        if (active) litLeft = 3; else if (litLeft > 0) litLeft--;
        lit = litLeft > 0;

        BlockState cur = w.getBlockState(pos);
        if (cur.getBlock() instanceof FluxBlock) {
            BlockState want = ((FluxBlock) cur.getBlock()).visual(cur, this, active);
            if (want != cur) w.setBlockState(pos, want, Block.NOTIFY_LISTENERS);
        }
        if (dirtyFlag) {
            dirtyFlag = false;
            markDirty();
            netDirty = true;
        }
        if (netDirty && timer % 20 == 0) {
            netDirty = false;
            BlockState s2 = w.getBlockState(pos);
            w.updateListeners(pos, s2, s2, Block.NOTIFY_LISTENERS);
        }
    }

    private void take(int a) {
        amount -= a;
        if (amount <= 0) {
            amount = 0;
            fluid = FluidKind.NONE;
        }
        changed();
    }

    private void pushFluid(ServerWorld w, BlockPos pos, BlockState st, Role r) {
        for (Direction d : Direction.values()) {
            if (amount <= 0) return;
            if (r == Role.PUMP && d != st.get(Properties.FACING)) continue;
            if (!r.fluidSide(st, d)) continue;
            BlockEntity b = w.getBlockEntity(pos.offset(d));
            if (!(b instanceof FluxBE) || b == this) continue;
            FluxBE n = (FluxBE) b;
            Role nr = n.role();
            if (nr.fluidCap <= 0 || !nr.fluidSide(n.getCachedState(), d.getOpposite())) continue;
            int want;
            if (r == Role.PUMP || r == Role.SUCTION) {
                want = amount;
            } else if (nr == Role.DYNAMO || nr == Role.MIXER) {
                want = Math.min(amount, FLUID_FLOW);
            } else {
                long diff = (long) amount * nr.fluidCap - (long) n.amount * r.fluidCap;
                if (diff <= 0) continue;
                want = (int) Math.min(FLUID_FLOW, diff / (r.fluidCap + nr.fluidCap));
            }
            if (want <= 0) continue;
            int acc = n.accept(fluid, want, d.getOpposite());
            if (acc > 0) {
                take(acc);
                moved += acc;
            }
        }
    }

    private void pushEnergy(ServerWorld w, BlockPos pos, Role r) {
        for (Direction d : Direction.values()) {
            if (energy <= 0) return;
            BlockEntity b = w.getBlockEntity(pos.offset(d));
            if (!(b instanceof FluxBE) || b == this) continue;
            FluxBE n = (FluxBE) b;
            Role nr = n.role();
            if (nr.energyCap <= 0) continue;
            long diff = (long) energy * nr.energyCap - (long) n.energy * r.energyCap;
            if (diff <= 0) continue;
            int want = (int) Math.min(ENERGY_FLOW, diff / (r.energyCap + nr.energyCap));
            if (want <= 0) continue;
            int acc = n.acceptEnergy(want);
            if (acc > 0) {
                energy -= acc;
                changed();
            }
        }
    }

    // ---------------------------------------------------------------- Maschinen

    private boolean dynamo() {
        Role r = Role.DYNAMO;
        if (burn <= 0 && fluid == FluidKind.LAVA && amount >= 50 && energy < r.energyCap - 400) {
            take(50);
            burn = 40;
        }
        if (burn > 0) {
            int gen = Math.min(40, r.energyCap - energy);
            if (gen > 0) {
                energy += gen;
                burn--;
                changed();
                return true;
            }
        }
        return false;
    }

    private boolean pump(ServerWorld w, BlockPos pos, BlockState st) {
        if (energy < 10) return false;
        Direction f = st.get(Properties.FACING);
        int room = Role.PUMP.fluidCap - amount;
        if (room > 0) {
            BlockEntity b = w.getBlockEntity(pos.offset(f.getOpposite()));
            if (b instanceof FluxBE && b != this) {
                FluxBE n = (FluxBE) b;
                if (n.canDrain(f) && n.amount > 0 && (amount == 0 || fluid == n.fluid)) {
                    FluidKind k = n.fluid;
                    int got = n.drain(Math.min(room, Math.min(n.amount, 500)));
                    if (got > 0) {
                        fluid = k;
                        amount += got;
                        changed();
                    }
                }
            }
        }
        if (amount > 0) {
            pushFluid(w, pos, st, Role.PUMP);
            if (moved > 0) {
                energy -= 10;
                changed();
                return true;
            }
        }
        return false;
    }

    private boolean suction(ServerWorld w, BlockPos pos, BlockState st) {
        if (energy < 10) return false;
        Direction f = st.get(Properties.FACING);
        BlockPos tp = pos.offset(f);
        boolean sucked = false;
        int room = Role.SUCTION.fluidCap - amount;
        if (room > 0) {
            BlockEntity b = w.getBlockEntity(tp);
            if (b instanceof FluxBE) {
                FluxBE t = (FluxBE) b;
                if (t.canDrain(f.getOpposite()) && t.amount > 0 && (amount == 0 || fluid == t.fluid)) {
                    FluidKind k = t.fluid;
                    int got = t.drain(Math.min(room, Math.min(t.amount, 500)));
                    if (got > 0) {
                        fluid = k;
                        amount += got;
                        sucked = true;
                    }
                }
            } else {
                sucked = suckWorld(w, tp, room);
            }
        }
        if (sucked) {
            energy -= 10;
            changed();
        }
        if (amount > 0) pushFluid(w, pos, st, Role.SUCTION);
        return sucked || moved > 0;
    }

    private boolean suckWorld(ServerWorld w, BlockPos tp, int room) {
        BlockState ts = w.getBlockState(tp);
        FluidKind k = FluidKind.NONE;
        int vol = 0;
        BlockState replace = null;
        if (ts.isOf(Blocks.WATER_CAULDRON)) {
            int lv = ts.get(LeveledCauldronBlock.LEVEL);
            k = FluidKind.WATER;
            vol = 333;
            replace = lv <= 1 ? Blocks.CAULDRON.getDefaultState() : ts.with(LeveledCauldronBlock.LEVEL, lv - 1);
        } else if (ts.isOf(Blocks.LAVA_CAULDRON)) {
            k = FluidKind.LAVA;
            vol = 1000;
            replace = Blocks.CAULDRON.getDefaultState();
        } else if (ts.getBlock() instanceof FluidBlock) {
            FluidState fs = ts.getFluidState();
            if (fs.isStill()) {
                if (fs.isOf(Fluids.WATER)) k = FluidKind.WATER;
                else if (fs.isOf(Fluids.LAVA)) k = FluidKind.LAVA;
                if (k != FluidKind.NONE) {
                    vol = 1000;
                    replace = Blocks.AIR.getDefaultState();
                }
            }
        }
        if (k == FluidKind.NONE || replace == null || vol > room || (amount > 0 && fluid != k)) return false;
        w.setBlockState(tp, replace, Block.NOTIFY_ALL);
        fluid = k;
        amount += vol;
        changed();
        return true;
    }

    private boolean mixer(ServerWorld w, BlockPos pos) {
        if (mixWater >= 1000 && mixLava >= 1000 && energy >= 5) {
            energy -= 5;
            progress++;
            changed();
            if (progress >= 20) {
                progress = 0;
                mixWater -= 1000;
                mixLava -= 1000;
                ItemScatterer.spawn(w, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, new ItemStack(Items.OBSIDIAN));
                w.playSound(null, pos, SoundEvents.BLOCK_LAVA_EXTINGUISH, SoundCategory.BLOCKS, 0.6f, 1f);
            }
            return true;
        }
        if (progress != 0) {
            progress = 0;
            changed();
        }
        return false;
    }

    // ---------------------------------------------------------------- Speichern / Sync

    @Override
    public void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.readNbt(nbt, lookup);
        fluid = FluidKind.fromId(nbt.getString("Fluid"));
        amount = nbt.getInt("Amount");
        energy = nbt.getInt("Energy");
        mixWater = nbt.getInt("MixWater");
        mixLava = nbt.getInt("MixLava");
        burn = nbt.getInt("Burn");
        progress = nbt.getInt("Progress");
    }

    @Override
    public void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.writeNbt(nbt, lookup);
        nbt.putString("Fluid", fluid.id);
        nbt.putInt("Amount", amount);
        nbt.putInt("Energy", energy);
        nbt.putInt("MixWater", mixWater);
        nbt.putInt("MixLava", mixLava);
        nbt.putInt("Burn", burn);
        nbt.putInt("Progress", progress);
    }

    @Override
    public Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }

    @Override
    public NbtCompound toInitialChunkDataNbt(RegistryWrapper.WrapperLookup lookup) {
        return createNbt(lookup);
    }

    // ---------------------------------------------------------------- Anzeige (Client)

    public List<Text> hudLines(boolean wrench) {
        List<Text> out = new ArrayList<>();
        Role r = role();
        if (r.fluidCap > 0 && (r == Role.TANK || wrench)) {
            if (r == Role.MIXER) {
                out.add(Text.translatable("hud.fluxwerk.fluid", FluidKind.WATER.displayName(), mixWater, r.fluidCap));
                out.add(Text.translatable("hud.fluxwerk.fluid", FluidKind.LAVA.displayName(), mixLava, r.fluidCap));
            } else if (amount > 0) {
                out.add(Text.translatable("hud.fluxwerk.fluid", fluid.displayName(), amount, r.fluidCap));
            } else {
                out.add(Text.translatable("hud.fluxwerk.empty", r.fluidCap));
            }
        }
        if (wrench) {
            if (r == Role.FILTER) {
                FluidKind f = getCachedState().get(FluxBlock.FLUID);
                out.add(Text.translatable("hud.fluxwerk.filter", f == FluidKind.NONE ? Text.translatable("hud.fluxwerk.any") : f.displayName()));
            }
            if (r.energyCap > 0) {
                out.add(Text.translatable("hud.fluxwerk.energy", energy, r.energyCap));
                if (r.energyUse > 0) out.add(Text.translatable("hud.fluxwerk.use", r.energyUse));
                if (r == Role.DYNAMO) {
                    out.add(Text.translatable(burn > 0 ? "hud.fluxwerk.gen" : "hud.fluxwerk.idle", 200));
                }
            }
        }
        return out;
    }

    public float barFraction() {
        Role r = role();
        if (r.fluidCap <= 0 || r == Role.MIXER) return -1f;
        return Math.min(1f, amount / (float) r.fluidCap);
    }
}
