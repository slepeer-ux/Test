package de.fluxwerk;

import net.minecraft.server.network.ServerPlayerEntity;

import java.util.ArrayList;
import java.util.List;

/** Das Fluxwerk-Handbuch (normales Schreib-Buch, wird per give-Befehl erzeugt). */
public final class Manual {
    private Manual() {}

    private static final String[] PAGES = {
        "FLUXWERK\n\nHandbuch\n\nFluessigkeiten, Energie und Maschinen.\n\nFluessigkeiten: Wasser, Lava, Milch.\nEinheit: mB (1000 mB = 1 Eimer).\nEnergie: E.",
        "FLUX-SCHLUESSEL\n\nHalte ihn in der Hand und schau einen Block an: Du siehst Fuellstand und Energie.\n\nRechtsklick: Pumpe/Saugeinheit drehen.\nSchleichen + Rechtsklick: Tank leeren, Filter loeschen.\n\nTanks zeigen ihren Inhalt immer an.",
        "FLUX-ROHR\n\nLeitet Fluessigkeit (1000 mB Puffer). Verbindet sich automatisch mit Nachbarn.\n\nFluessigkeit fliesst vom volleren zum leereren Block und gleicht sich aus. Das Rohr zeigt die Farbe der Fluessigkeit.",
        "FLUX-TANK\n\nSpeichert 8000 mB.\n\nRechtsklick mit vollem Eimer: einfuellen.\nRechtsklick mit leerem Eimer: Eimer fuellen (Wasser, Lava, Milch).\n\nSpender (Dispenser) mit Eimer vor dem Tank fuellt und leert ihn ebenfalls. Comparator gibt den Fuellstand aus.",
        "SAUGEINHEIT\n\nDer Mund zeigt auf den Block, an den du sie setzt. Saugt aus Tanks, Kesseln und Wasser-/Lavaquellen. Gibt die Fluessigkeit an alle anderen Seiten weiter, zum Beispiel direkt in ein Rohr.\n\nBraucht Energie (50 E/s).",
        "DRUCKPUMPE\n\nSaugt hinten an und drueckt vorne mit hohem Druck heraus. Der Pfeil zeigt in Blickrichtung beim Setzen.\n\nBraucht Energie (50 E/s), solange sie arbeitet.",
        "VENTIL\n\nOffen im Normalzustand. Ein Redstone-Signal schliesst es. So steuerst du Leitungen per Hebel oder Schaltung.\n\nFILTER\n\nLaesst nur eine Fluessigkeit durch. Mit vollem Eimer rechtsklicken, um sie einzustellen.",
        "MESSGERAET\n\nRohrstueck mit Zeiger. Gibt per Comparator 0 bis 15 je nach Fuellstand aus.\n\nMISCHER\n\nWasser + Lava + Energie ergibt Obsidian. Fuelle ihn per Rohr oder Eimer (je 2000 mB). 1000 mB von jedem pro Obsidian, 25 E/s.",
        "FLUX-DYNAMO\n\nVerbrennt Lava (50 mB pro Zyklus) und erzeugt 200 E/s. Stelle sie neben Maschinen oder verbinde sie per Flux-Kabel.\n\nFLUX-KABEL\n\nLeitet Energie (2000 E Puffer). Verbindet sich automatisch.",
        "BEISPIEL\n\nTank - Rohr - Dynamo: Lava wird zu Energie.\n\nQuelle - Saugeinheit - Rohr - Tank: automatisch Wasser sammeln.\n\nMit /fluxwerk handbuch bekommst du dieses Buch jederzeit neu. Viel Spass!"
    };

    private static String esc(String s) {
        return s.replace("\\", "").replace("\"", "").replace("'", "").replace("\n", "\\\\n");
    }

    public static void give(ServerPlayerEntity player) {
        List<String> pages = new ArrayList<>();
        for (String p : PAGES) pages.add("'{\"text\":\"" + esc(p) + "\"}'");
        String cmd = "give @s minecraft:written_book[minecraft:written_book_content={title:\"Fluxwerk Handbuch\",author:\"Fluxwerk\",pages:["
                + String.join(",", pages) + "]}]";
        player.getServer().getCommandManager().executeWithPrefix(player.getCommandSource().withLevel(4).withSilent(), cmd);
    }
}
