package de.fluxwerk;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.state.StateManager;

/** Messgeraet: Rohrstueck mit Zeiger und Redstone-Comparator-Ausgang. */
public class MeterBlock extends FluxBlock {
    public static final MapCodec<MeterBlock> CODEC = createCodec(MeterBlock::new);

    public MeterBlock(Settings settings) {
        super(settings, Role.METER);
        setDefaultState(getDefaultState().with(LEVEL, 0));
    }

    @Override
    public MapCodec<MeterBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(LEVEL);
    }

    @Override
    public BlockState visual(BlockState st, FluxBE be, boolean active) {
        int cap = Role.METER.fluidCap;
        int lvl = be.amount <= 0 ? 0 : Math.min(4, 1 + be.amount * 4 / (cap + 1));
        return st.get(LEVEL) == lvl ? st : st.with(LEVEL, lvl);
    }
}
