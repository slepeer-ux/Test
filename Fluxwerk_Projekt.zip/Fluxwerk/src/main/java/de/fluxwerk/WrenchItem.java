package de.fluxwerk;

import net.minecraft.block.BlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Flux-Schluessel: zeigt Fuellstand/Energie an und stellt Maschinen ein. */
public class WrenchItem extends Item {
    public WrenchItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext ctx) {
        World w = ctx.getWorld();
        BlockPos p = ctx.getBlockPos();
        BlockState s = w.getBlockState(p);
        if (!(s.getBlock() instanceof FluxBlock) || ctx.getPlayer() == null) return ActionResult.PASS;
        return ((FluxBlock) s.getBlock()).wrench(w, p, s, ctx.getPlayer());
    }
}
