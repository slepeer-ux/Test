package de.fluxwerk;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Properties;

public class CableBlock extends ConduitBlock {
    public static final MapCodec<CableBlock> CODEC = createCodec(CableBlock::new);

    public CableBlock(Settings settings) {
        super(settings, Role.CABLE, 6);
        setDefaultState(noConnections(getDefaultState()).with(Properties.LIT, false));
    }

    @Override
    public MapCodec<CableBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        super.appendProperties(builder);
        builder.add(Properties.LIT);
    }

    @Override
    public BlockState visual(BlockState st, FluxBE be, boolean active) {
        boolean cur = st.get(Properties.LIT);
        boolean want = cur ? be.energy >= 30 : be.energy >= 150;
        return want == cur ? st : st.with(Properties.LIT, want);
    }
}
