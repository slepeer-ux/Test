package de.fluxwerk;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.world.World;

public class TankBlock extends FluxBlock {
    public static final MapCodec<TankBlock> CODEC = createCodec(TankBlock::new);

    public TankBlock(Settings settings) {
        super(settings, Role.TANK);
        setDefaultState(getDefaultState().with(FLUID, FluidKind.NONE).with(LEVEL, 0));
    }

    @Override
    public MapCodec<TankBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FLUID, LEVEL);
    }

    @Override
    public BlockState visual(BlockState st, FluxBE be, boolean active) {
        int cap = Role.TANK.fluidCap;
        int lvl = be.amount <= 0 ? 0 : Math.min(4, (be.amount * 4 + cap - 1) / cap);
        FluidKind k = lvl == 0 ? FluidKind.NONE : be.fluid;
        if (st.get(FLUID) == k && st.get(LEVEL) == lvl) return st;
        return st.with(FLUID, k).with(LEVEL, lvl);
    }

    /** Schluessel + Schleichen = Tank leeren. */
    @Override
    public ActionResult wrench(World world, BlockPos pos, BlockState state, PlayerEntity player) {
        if (!player.isSneaking()) return ActionResult.PASS;
        if (!world.isClient) {
            BlockEntity be = world.getBlockEntity(pos);
            if (be instanceof FluxBE) {
                FluxBE f = (FluxBE) be;
                f.drain(f.amount);
                f.sync();
                player.sendMessage(Text.translatable("msg.fluxwerk.tank_cleared"), true);
            }
        }
        return ActionResult.SUCCESS;
    }
}
